import setuptools
setuptools.setup(
    name= 'culculator',
    version= '0.1',
    author= 'Amdjed',
    description= 'culculator ',
    packages=setuptools.find_packages(),
    classifiers=[
    "Programming Language :: Python :: 3",
    "Operating System :: OS Independent",
    "License :: OSI Approved :: MIT License"
    ]
)